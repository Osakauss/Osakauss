#include "tar.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *disk;

static int oct2bin(unsigned char *str, int size) {
    int n = 0;
    unsigned char *c = str;
    while (size-- > 0) {
        n *= 8;
        n += *c - '0';
        c++;
    }
    return n;
}

int tarfwrite(struct file file, char * data){
    struct file_header header;

    fseek(disk,file.offset,SEEK_SET);

    fread(&header, sizeof(header), 1, disk);

    return 0;
}
struct file tarfopen(char *name){
    struct file file;
    struct file_header header;
    int filesize;
    int ds; // disk size
    int pos;
    while(1){
        if (fread(&header, sizeof(header) ,1, disk) == EOF){
            break;
        }
        //printf("name = %s\nfile disk size = %d\nustar = %s\n",header.name, ds, header.ustar);
        if (strcmp(header.ustar, "ustar") != 0){
            break;
        }

        printf("%d\n",oct2bin(header.uid,6));



        filesize = oct2bin(header.size, 11);
        ds = ( ( (filesize / 513) * 512 ) + 512) ;
        if (strcmp(name, header.name) == 0){
            file.offset = pos;
            file.size = filesize;
            file.disksize = ds;
            return file;
        }
        pos += 512 + ds;
        fseek(disk,pos,SEEK_SET);
    }
    file.error = 1;
    return file;
}



char *tarfread(struct file file,int size){
    struct file_header header;
    char *string = (char*)malloc(size);

    fseek(disk,file.offset,SEEK_SET);

    if (fread(&header, sizeof(header) ,1, disk) == EOF){
        return NULL;
    }
    if (strcmp(header.ustar, "ustar") != 0){
        return NULL;
    }

    if (file.size < size){
        return NULL;
    }
    fread( string, size, 1, disk);
    return string;
}


void ls(){
    struct file_header header;
    int filesize;
    int ds; // disk size
    int pos;
    while(1){
        if (fread(&header, sizeof(header) ,1, disk) == EOF){
            break;
        }
        //printf("name = %s\nfile disk size = %d\nustar = %s\n",header.name, ds, header.ustar);
        if (strcmp(header.ustar, "ustar") != 0){
            break;
        }
        filesize = oct2bin(header.size, 11);
        ds = ( ( (filesize / 513) * 512 ) + 512) ;
        printf("name = %s\nfile disk size = %d\n",header.name, ds, header.ustar);
        pos += 512 + ds;
        fseek(disk,pos,SEEK_SET);
    }
    return;
}

int main(){
    
    char *string = (char*)malloc(100);
    disk = fopen ("file.tar", "rb");
    if (ferror(disk)){
        fprintf(stderr, "\nError when opening file\n");
    }


    struct file myfile = tarfopen("file.txt");
    if (myfile.error == 1){
        printf("Error finding file");
        return 1;

    }
    string = tarfread(myfile, 18);
    
    printf("string = %s", string);

    fseek(disk,0,SEEK_SET);

    fclose(disk);
    return 0;
}
